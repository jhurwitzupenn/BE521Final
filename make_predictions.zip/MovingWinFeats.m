function output = MovingWinFeats(x, fs, winLen, winDisp, featFn)

NumWins = @(xLen, fs, winLen, winDisp) round(xLen/(winDisp*fs) - winLen/winDisp+1);
outputlength = NumWins(length(x), fs, winLen, winDisp);
output = zeros(outputlength,1);
start = 1;

% For each window, calculate the number of features
for i = 1:outputlength
    if i==outputlength
        tic;
    end
    currentwindow = x(start:(start+winLen*fs-1));
    output(i) = featFn(currentwindow);
    start = start + winDisp*fs;
end
end